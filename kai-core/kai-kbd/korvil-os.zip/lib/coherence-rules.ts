// ============================================================================
// KORVIL OS — REGRAS DE COERENCIA
// Valida registros contra o esquema do setor/colecao antes de gravar.
// ============================================================================

import { getCollection, type FieldSchema } from "./constants"

export interface CoherenceIssue {
  field: string
  message: string
}

function checkField(field: FieldSchema, value: unknown): CoherenceIssue | null {
  const empty = value === undefined || value === null || value === ""
  if (field.required && empty) {
    return { field: field.key, message: `"${field.label}" e obrigatorio.` }
  }
  if (empty) return null

  switch (field.type) {
    case "number":
      if (isNaN(Number(value))) return { field: field.key, message: `"${field.label}" deve ser numerico.` }
      break
    case "email":
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value)))
        return { field: field.key, message: `"${field.label}" nao e um email valido.` }
      break
    case "url":
      try {
        new URL(String(value))
      } catch {
        return { field: field.key, message: `"${field.label}" nao e uma URL valida.` }
      }
      break
    case "select":
      if (field.options && !field.options.includes(String(value)))
        return { field: field.key, message: `"${field.label}" tem valor fora das opcoes permitidas.` }
      break
    default:
      break
  }
  return null
}

export function validateRecord(
  sector: string,
  collection: string,
  data: Record<string, unknown>,
): { ok: boolean; issues: CoherenceIssue[] } {
  const schema = getCollection(sector, collection)
  if (!schema) return { ok: true, issues: [] }
  const issues: CoherenceIssue[] = []
  for (const field of schema.fields) {
    const issue = checkField(field, data[field.key])
    if (issue) issues.push(issue)
  }
  return { ok: issues.length === 0, issues }
}

/** Retorna valores padrao a partir do esquema. */
export function defaultsFor(sector: string, collection: string): Record<string, unknown> {
  const schema = getCollection(sector, collection)
  if (!schema) return {}
  const out: Record<string, unknown> = {}
  for (const f of schema.fields) {
    if (f.defaultValue !== undefined) out[f.key] = f.defaultValue
    else if (f.type === "boolean") out[f.key] = false
    else if (f.type === "number") out[f.key] = 0
    else if (f.type === "tags") out[f.key] = []
    else out[f.key] = ""
  }
  return out
}
