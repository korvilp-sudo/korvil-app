// ============================================================================
// KORVIL OS — CONSTANTES GLOBAIS
// Mapa mestre de setores, colecoes e esquemas de formularios universais.
// Toda a aplicacao (DB, admin CRUD, voz, forge) e alimentada por este mapa.
// ============================================================================

export const OS_NAME = "KORVIL OS"
export const OS_CODENAME = "K-AI: Modo Forja / K-B.D"
export const OS_VERSION = "1.0.0"
export const REPO_OWNER = "korvilp-sudo"
export const REPO_NAME = "korvil-app"
export const REPO_URL = `https://github.com/${REPO_OWNER}/${REPO_NAME}`

// Palavras de ativacao do assistente de voz.
export const WAKE_WORDS = ["k-ai", "kai", "kay", "caio", "korvil"]
export const VOICE_TIMER_SECONDS = 5

// Chaves de armazenamento local.
export const LS_PREFIX = "korvil_os_v1"
export const LS_DB_KEY = `${LS_PREFIX}::db`
export const LS_RECYCLE_KEY = `${LS_PREFIX}::recycle`
export const LS_EXP_KEY = `${LS_PREFIX}::exp`
export const LS_LOGS_KEY = `${LS_PREFIX}::logs`
export const LS_PAT_KEY = `${LS_PREFIX}::github_pat`
export const LS_SESSION_KEY = `${LS_PREFIX}::session`
export const LS_SETTINGS_KEY = `${LS_PREFIX}::settings`

// ----------------------------------------------------------------------------
// TIPOS DE CAMPO PARA FORMULARIOS UNIVERSAIS ADAPTATIVOS
// ----------------------------------------------------------------------------
export type FieldType =
  | "text"
  | "textarea"
  | "number"
  | "email"
  | "password"
  | "select"
  | "boolean"
  | "date"
  | "tags"
  | "url"
  | "color"

export interface FieldSchema {
  key: string
  label: string
  type: FieldType
  required?: boolean
  placeholder?: string
  options?: string[]
  defaultValue?: string | number | boolean | string[]
  help?: string
}

export interface CollectionSchema {
  key: string
  label: string
  icon: string
  description: string
  fields: FieldSchema[]
}

export interface SectorSchema {
  key: string
  label: string
  short: string
  color: string
  description: string
  collections: CollectionSchema[]
}

// Campos base reutilizaveis.
const baseName: FieldSchema = { key: "nome", label: "Nome", type: "text", required: true, placeholder: "Titulo do registro" }
const baseDesc: FieldSchema = { key: "descricao", label: "Descricao", type: "textarea", placeholder: "Detalhes..." }
const baseStatus: FieldSchema = {
  key: "status",
  label: "Status",
  type: "select",
  options: ["Ativo", "Rascunho", "Arquivado"],
  defaultValue: "Ativo",
}
const baseTags: FieldSchema = { key: "tags", label: "Tags", type: "tags", placeholder: "adicione e tecle Enter" }

// ----------------------------------------------------------------------------
// ESQUEMA MESTRE DE SETORES / COLECOES
// ----------------------------------------------------------------------------
export const SECTORS: SectorSchema[] = [
  {
    key: "sistema-k",
    label: "Sistema K",
    short: "SK",
    color: "chart-1",
    description: "Metodos, protocolos, desafios, pilares e mindset do sistema KORVIL.",
    collections: [
      {
        key: "metodos",
        label: "Metodos",
        icon: "Compass",
        description: "Metodologias do sistema K.",
        fields: [baseName, baseDesc, { key: "etapas", label: "Etapas", type: "number", defaultValue: 1 }, baseStatus, baseTags],
      },
      {
        key: "protocolos",
        label: "Protocolos",
        icon: "ListChecks",
        description: "Protocolos operacionais.",
        fields: [baseName, baseDesc, { key: "duracao", label: "Duracao (dias)", type: "number", defaultValue: 7 }, baseStatus, baseTags],
      },
      {
        key: "desafios",
        label: "Desafios",
        icon: "Flag",
        description: "Desafios e missoes.",
        fields: [baseName, baseDesc, { key: "dificuldade", label: "Dificuldade", type: "select", options: ["Facil", "Medio", "Dificil", "Extremo"], defaultValue: "Medio" }, baseStatus, baseTags],
      },
      { key: "pilares", label: "Pilares", icon: "Columns3", description: "Pilares fundamentais.", fields: [baseName, baseDesc, baseStatus] },
      { key: "mindset", label: "Mindset", icon: "Brain", description: "Mentalidade e crencas.", fields: [baseName, baseDesc, baseTags] },
      { key: "livros", label: "Livros", icon: "BookOpen", description: "Biblioteca de referencia.", fields: [baseName, { key: "autor", label: "Autor", type: "text" }, baseDesc, baseTags] },
      { key: "manifestos", label: "Manifestos", icon: "ScrollText", description: "Declaracoes e manifestos.", fields: [baseName, baseDesc] },
    ],
  },
  {
    key: "k-tp",
    label: "K-TP",
    short: "TP",
    color: "chart-3",
    description: "Personal Trainer: treinos, dietas, avaliacoes, alunos e exercicios.",
    collections: [
      {
        key: "treinos",
        label: "Treinos",
        icon: "Dumbbell",
        description: "Fichas de treino.",
        fields: [
          baseName,
          { key: "objetivo", label: "Objetivo", type: "select", options: ["Hipertrofia", "Emagrecimento", "Forca", "Resistencia", "Mobilidade"], defaultValue: "Hipertrofia" },
          { key: "nivel", label: "Nivel", type: "select", options: ["Iniciante", "Intermediario", "Avancado"], defaultValue: "Iniciante" },
          { key: "frequencia", label: "Frequencia (x/semana)", type: "number", defaultValue: 3 },
          baseDesc,
          baseTags,
        ],
      },
      {
        key: "dietas",
        label: "Dietas",
        icon: "Salad",
        description: "Planos alimentares.",
        fields: [baseName, { key: "calorias", label: "Calorias (kcal)", type: "number", defaultValue: 2000 }, { key: "proteinas", label: "Proteinas (g)", type: "number", defaultValue: 120 }, baseDesc, baseTags],
      },
      { key: "avaliacoes", label: "Avaliacoes", icon: "ClipboardList", description: "Avaliacoes fisicas.", fields: [baseName, { key: "peso", label: "Peso (kg)", type: "number" }, { key: "gordura", label: "% Gordura", type: "number" }, baseDesc] },
      { key: "alunos", label: "Alunos", icon: "Users", description: "Cadastro de alunos.", fields: [baseName, { key: "email", label: "Email", type: "email" }, { key: "telefone", label: "Telefone", type: "text" }, baseStatus] },
      { key: "exercicios", label: "Exercicios", icon: "Activity", description: "Biblioteca de exercicios.", fields: [baseName, { key: "grupo", label: "Grupo Muscular", type: "select", options: ["Peito", "Costas", "Perna", "Ombro", "Braco", "Core"], defaultValue: "Peito" }, baseDesc] },
      { key: "suplementos", label: "Suplementos", icon: "Pill", description: "Suplementacao.", fields: [baseName, { key: "dose", label: "Dose", type: "text" }, baseDesc] },
      { key: "consultorias", label: "Consultorias", icon: "Headset", description: "Sessoes de consultoria.", fields: [baseName, { key: "data", label: "Data", type: "date" }, baseDesc, baseStatus] },
      { key: "planos", label: "Planos", icon: "Package", description: "Planos comerciais.", fields: [baseName, { key: "preco", label: "Preco (R$)", type: "number" }, baseDesc, baseStatus] },
      { key: "anamneses", label: "Anamneses", icon: "FileHeart", description: "Historico de saude.", fields: [baseName, baseDesc] },
    ],
  },
  {
    key: "k-afortunado",
    label: "K-Afortunado",
    short: "KA",
    color: "chart-2",
    description: "Prosperidade: financas, cursos, afirmacoes, mentorias e metas.",
    collections: [
      { key: "financas", label: "Financas", icon: "Wallet", description: "Registros financeiros.", fields: [baseName, { key: "tipo", label: "Tipo", type: "select", options: ["Receita", "Despesa", "Investimento"], defaultValue: "Receita" }, { key: "valor", label: "Valor (R$)", type: "number" }, { key: "data", label: "Data", type: "date" }, baseDesc] },
      { key: "cursos-prosperidade", label: "Cursos", icon: "GraduationCap", description: "Cursos de prosperidade.", fields: [baseName, baseDesc, { key: "aulas", label: "Aulas", type: "number", defaultValue: 1 }, baseStatus, baseTags] },
      { key: "afirmacoes", label: "Afirmacoes", icon: "Sparkles", description: "Afirmacoes positivas.", fields: [baseName, baseDesc] },
      { key: "planilhas", label: "Planilhas", icon: "Table2", description: "Planilhas de controle.", fields: [baseName, { key: "url", label: "URL", type: "url" }, baseDesc] },
      { key: "mentorias", label: "Mentorias", icon: "UserCheck", description: "Programas de mentoria.", fields: [baseName, baseDesc, { key: "preco", label: "Preco (R$)", type: "number" }, baseStatus] },
      { key: "investimentos", label: "Investimentos", icon: "TrendingUp", description: "Carteira de investimentos.", fields: [baseName, { key: "aporte", label: "Aporte (R$)", type: "number" }, { key: "rentabilidade", label: "Rentab. (%)", type: "number" }, baseDesc] },
      { key: "metas", label: "Metas", icon: "Target", description: "Metas financeiras.", fields: [baseName, { key: "alvo", label: "Alvo (R$)", type: "number" }, { key: "prazo", label: "Prazo", type: "date" }, baseStatus] },
    ],
  },
  {
    key: "k-alma",
    label: "K-Alma",
    short: "AL",
    color: "chart-4",
    description: "Terapias, meditacoes, cristais, chakras e frequencias binaurais.",
    collections: [
      { key: "terapias", label: "Terapias", icon: "HeartPulse", description: "Terapias holisticas.", fields: [baseName, baseDesc, { key: "duracao", label: "Duracao (min)", type: "number", defaultValue: 60 }, baseStatus, baseTags] },
      { key: "meditacoes", label: "Meditacoes", icon: "Flower2", description: "Guias de meditacao.", fields: [baseName, baseDesc, { key: "duracao", label: "Duracao (min)", type: "number", defaultValue: 10 }] },
      { key: "cristais", label: "Cristais", icon: "Gem", description: "Cristais e propriedades.", fields: [baseName, baseDesc, { key: "cor", label: "Cor", type: "color", defaultValue: "#22d3ee" }] },
      { key: "jornadas", label: "Jornadas", icon: "Route", description: "Jornadas de autoconhecimento.", fields: [baseName, baseDesc, baseStatus] },
      { key: "chakras", label: "Chakras", icon: "CircleDot", description: "Sistema de chakras.", fields: [baseName, baseDesc, { key: "cor", label: "Cor", type: "color", defaultValue: "#a855f7" }] },
      { key: "audios-binaurais", label: "Audios Binaurais", icon: "AudioLines", description: "Batidas binaurais.", fields: [baseName, { key: "frequencia", label: "Frequencia (Hz)", type: "number", defaultValue: 432 }, baseDesc] },
      { key: "frequencias", label: "Frequencias", icon: "Radio", description: "Frequencias de cura.", fields: [baseName, { key: "hz", label: "Hz", type: "number", defaultValue: 528 }, baseDesc] },
      { key: "rituais", label: "Rituais", icon: "Sun", description: "Rituais e praticas.", fields: [baseName, baseDesc] },
    ],
  },
  {
    key: "central",
    label: "Central KORVIL",
    short: "CK",
    color: "chart-1",
    description: "Cursos, parceiros, profissionais, lojas, pedidos e comissoes.",
    collections: [
      { key: "cursos", label: "Cursos", icon: "GraduationCap", description: "Catalogo de cursos.", fields: [baseName, baseDesc, { key: "preco", label: "Preco (R$)", type: "number" }, baseStatus, baseTags] },
      { key: "parceiros", label: "Parceiros", icon: "Handshake", description: "Rede de parceiros.", fields: [baseName, { key: "email", label: "Email", type: "email" }, baseDesc, baseStatus] },
      { key: "profissionais", label: "Profissionais", icon: "BadgeCheck", description: "Profissionais cadastrados.", fields: [baseName, { key: "area", label: "Area", type: "text" }, { key: "email", label: "Email", type: "email" }, baseStatus] },
      { key: "loja-fisica", label: "Loja Fisica", icon: "Store", description: "Produtos da loja fisica.", fields: [baseName, { key: "preco", label: "Preco (R$)", type: "number" }, { key: "estoque", label: "Estoque", type: "number" }, baseStatus] },
      { key: "loja-digital", label: "Loja Digital", icon: "ShoppingBag", description: "Produtos digitais.", fields: [baseName, { key: "preco", label: "Preco (R$)", type: "number" }, { key: "url", label: "URL Download", type: "url" }, baseStatus] },
      { key: "pedidos", label: "Pedidos", icon: "Receipt", description: "Pedidos realizados.", fields: [baseName, { key: "total", label: "Total (R$)", type: "number" }, { key: "status", label: "Status", type: "select", options: ["Pendente", "Pago", "Enviado", "Entregue", "Cancelado"], defaultValue: "Pendente" }] },
      { key: "cupons", label: "Cupons", icon: "Ticket", description: "Cupons de desconto.", fields: [baseName, { key: "desconto", label: "Desconto (%)", type: "number" }, { key: "ativo", label: "Ativo", type: "boolean", defaultValue: true }] },
      { key: "comissoes", label: "Comissoes", icon: "Percent", description: "Comissoes de afiliados.", fields: [baseName, { key: "percentual", label: "Percentual (%)", type: "number" }, baseDesc] },
      { key: "categorias", label: "Categorias", icon: "FolderTree", description: "Categorias do catalogo.", fields: [baseName, baseDesc] },
    ],
  },
  {
    key: "global",
    label: "Global",
    short: "GL",
    color: "chart-5",
    description: "Usuarios (Login KORVIL Index), configuracoes, midias, tags e logs.",
    collections: [
      {
        key: "usuarios",
        label: "Usuarios",
        icon: "UserCog",
        description: "Login KORVIL Index e permissoes.",
        fields: [
          { key: "nome", label: "Nome", type: "text", required: true },
          { key: "usuario", label: "Usuario (login)", type: "text", required: true },
          { key: "email", label: "Email", type: "email" },
          { key: "senha", label: "Senha", type: "password" },
          { key: "papel", label: "Papel", type: "select", options: ["Criador", "Admin", "Editor", "Visitante"], defaultValue: "Editor" },
          { key: "ativo", label: "Ativo", type: "boolean", defaultValue: true },
        ],
      },
      { key: "configuracoes", label: "Configuracoes", icon: "Settings2", description: "Config. do sistema.", fields: [baseName, { key: "valor", label: "Valor", type: "text" }, baseDesc] },
      { key: "midias", label: "Midias", icon: "Image", description: "Biblioteca de midias.", fields: [baseName, { key: "url", label: "URL", type: "url" }, { key: "tipo", label: "Tipo", type: "select", options: ["Imagem", "Video", "Audio", "Documento"], defaultValue: "Imagem" }] },
      { key: "tags", label: "Tags", icon: "Tags", description: "Tags globais.", fields: [baseName, { key: "cor", label: "Cor", type: "color", defaultValue: "#22d3ee" }] },
      { key: "logs", label: "Logs", icon: "ScrollText", description: "Logs do sistema.", fields: [baseName, baseDesc] },
      { key: "permissoes", label: "Permissoes", icon: "ShieldCheck", description: "Regras de permissao.", fields: [baseName, baseDesc] },
    ],
  },
  {
    key: "automation",
    label: "Automation",
    short: "AU",
    color: "chart-4",
    description: "Comandos de voz, scripts, prompts, gatilhos, macros e webhooks.",
    collections: [
      { key: "voice-commands", label: "Comandos de Voz", icon: "Mic", description: "Intencoes de voz.", fields: [baseName, { key: "gatilho", label: "Gatilho (frase)", type: "text" }, { key: "acao", label: "Acao", type: "text" }, baseDesc] },
      { key: "custom-scripts", label: "Scripts", icon: "Terminal", description: "Scripts customizados.", fields: [baseName, { key: "codigo", label: "Codigo", type: "textarea" }, baseStatus] },
      { key: "system-prompts", label: "System Prompts", icon: "MessageSquareCode", description: "Prompts do sistema.", fields: [baseName, { key: "prompt", label: "Prompt", type: "textarea" }] },
      { key: "action-history", label: "Historico", icon: "History", description: "Historico de acoes.", fields: [baseName, baseDesc] },
      { key: "triggers", label: "Gatilhos", icon: "Zap", description: "Gatilhos automaticos.", fields: [baseName, { key: "condicao", label: "Condicao", type: "text" }, baseStatus] },
      { key: "macros", label: "Macros", icon: "Layers", description: "Sequencias de acoes.", fields: [baseName, baseDesc] },
      { key: "webhooks", label: "Webhooks", icon: "Webhook", description: "Endpoints de webhook.", fields: [baseName, { key: "url", label: "URL", type: "url" }, baseStatus] },
    ],
  },
]

// Indice rapido setor -> colecao.
export function getSector(key: string): SectorSchema | undefined {
  return SECTORS.find((s) => s.key === key)
}
export function getCollection(sectorKey: string, colKey: string): CollectionSchema | undefined {
  return getSector(sectorKey)?.collections.find((c) => c.key === colKey)
}
export function collectionPath(sectorKey: string, colKey: string): string {
  return `data/korvil-db/${sectorKey}/${colKey}.json`
}
