import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// ---------------------------------------------------------------------------
// Utilitarios gerais do KORVIL OS
// ---------------------------------------------------------------------------

/** Gera um id unico e ordenavel por tempo. */
export function uid(prefix = "rec"): string {
  const t = Date.now().toString(36)
  const r = Math.random().toString(36).slice(2, 8)
  return `${prefix}_${t}${r}`
}

/** Formata timestamp para pt-BR. */
export function fmtDate(ts?: number | string): string {
  if (!ts) return "—"
  const d = typeof ts === "number" ? new Date(ts) : new Date(ts)
  if (isNaN(d.getTime())) return String(ts)
  return d.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

/** Retorna um resumo legivel de um objeto de registro. */
export function summarize(rec: Record<string, unknown>): string {
  const cand = rec.nome || rec.titulo || rec.label || rec.usuario || rec.id
  return cand ? String(cand) : "(sem nome)"
}

/** Serializa JSON com identacao segura. */
export function safeStringify(value: unknown): string {
  try {
    return JSON.stringify(value, null, 2)
  } catch {
    return "{}"
  }
}

/** Deep clone via JSON. */
export function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T
}

/** Normaliza texto para comparacao (sem acento / minusculo). */
export function normalize(text: string): string {
  return text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
}

/** Debounce simples. */
export function debounce<A extends unknown[]>(fn: (...args: A) => void, ms: number) {
  let t: ReturnType<typeof setTimeout> | null = null
  return (...args: A) => {
    if (t) clearTimeout(t)
    t = setTimeout(() => fn(...args), ms)
  }
}

/** Formata numero como moeda BRL. */
export function brl(value: number): string {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value || 0)
}
