"use client"

// ============================================================================
// KORVIL OS — AUTENTICACAO (Login KORVIL Index)
// Auth 100% local vinculada a colecao global/usuarios. Zero dependencia externa.
// ============================================================================

import { LS_SESSION_KEY } from "./constants"
import { listRecords, addLog, type DbRecord } from "./db"

export interface Session {
  userId: string
  usuario: string
  nome: string
  papel: string
  loggedAt: number
}

function isBrowser() {
  return typeof window !== "undefined"
}

export function getSession(): Session | null {
  if (!isBrowser()) return null
  try {
    const raw = window.localStorage.getItem(LS_SESSION_KEY)
    return raw ? (JSON.parse(raw) as Session) : null
  } catch {
    return null
  }
}

export function login(usuario: string, senha: string): { ok: boolean; error?: string; session?: Session } {
  const users = listRecords("global", "usuarios")
  const u = users.find(
    (x) => String(x.usuario).toLowerCase() === usuario.toLowerCase(),
  ) as DbRecord | undefined

  if (!u) return { ok: false, error: "Usuario nao encontrado." }
  if (u.ativo === false) return { ok: false, error: "Usuario inativo." }
  if (String(u.senha ?? "") !== senha) return { ok: false, error: "Senha incorreta." }

  const session: Session = {
    userId: u.id,
    usuario: String(u.usuario),
    nome: String(u.nome),
    papel: String(u.papel ?? "Editor"),
    loggedAt: Date.now(),
  }
  if (isBrowser()) window.localStorage.setItem(LS_SESSION_KEY, JSON.stringify(session))
  addLog("success", "auth", `Login realizado: ${session.usuario}`)
  return { ok: true, session }
}

export function logout() {
  if (isBrowser()) window.localStorage.removeItem(LS_SESSION_KEY)
  addLog("info", "auth", "Sessao encerrada.")
}

export function canWrite(session: Session | null): boolean {
  if (!session) return true // modo aberto local (plug & play)
  return ["Criador", "Admin", "Editor"].includes(session.papel)
}
