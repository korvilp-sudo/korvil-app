"use client"

// ============================================================================
// KORVIL OS — ENGINE DE BANCO DE DADOS (LocalStorage / Browser)
// "NUNCA PERDER / NUNCA ERRAR": exclusoes vao para a lixeira, nunca somem.
// Emite eventos para sincronizacao reativa entre componentes.
// ============================================================================

import {
  LS_DB_KEY,
  LS_RECYCLE_KEY,
  LS_LOGS_KEY,
  SECTORS,
  collectionPath,
} from "./constants"
import { uid, clone } from "./utils"

export interface DbRecord {
  id: string
  createdAt: number
  updatedAt: number
  [key: string]: unknown
}

export interface RecycleEntry {
  id: string
  deletedAt: number
  sector: string
  collection: string
  path: string
  record: DbRecord
  reason?: string
}

export interface LogEntry {
  id: string
  ts: number
  level: "info" | "success" | "warn" | "error"
  scope: string
  message: string
}

// Estrutura: db[sector][collection] = DbRecord[]
type Database = Record<string, Record<string, DbRecord[]>>

const EVENT = "korvil-db-change"

function isBrowser() {
  return typeof window !== "undefined"
}

function emit() {
  if (isBrowser()) window.dispatchEvent(new CustomEvent(EVENT))
}

export function onDbChange(cb: () => void): () => void {
  if (!isBrowser()) return () => {}
  window.addEventListener(EVENT, cb)
  window.addEventListener("storage", cb)
  return () => {
    window.removeEventListener(EVENT, cb)
    window.removeEventListener("storage", cb)
  }
}

// ---------------------------------------------------------------------------
// Leitura / escrita bruta
// ---------------------------------------------------------------------------
function readRaw<T>(key: string, fallback: T): T {
  if (!isBrowser()) return fallback
  try {
    const raw = window.localStorage.getItem(key)
    if (!raw) return fallback
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

function writeRaw(key: string, value: unknown) {
  if (!isBrowser()) return
  try {
    window.localStorage.setItem(key, JSON.stringify(value))
  } catch (e) {
    console.log("[v0] Falha ao escrever no LocalStorage:", (e as Error).message)
  }
}

// ---------------------------------------------------------------------------
// DATABASE
// ---------------------------------------------------------------------------
export function getDatabase(): Database {
  return readRaw<Database>(LS_DB_KEY, {})
}

function saveDatabase(db: Database) {
  writeRaw(LS_DB_KEY, db)
  emit()
}

export function listRecords(sector: string, collection: string): DbRecord[] {
  const db = getDatabase()
  return db[sector]?.[collection] ?? []
}

export function getRecord(sector: string, collection: string, id: string): DbRecord | undefined {
  return listRecords(sector, collection).find((r) => r.id === id)
}

export function createRecord(
  sector: string,
  collection: string,
  data: Record<string, unknown>,
): DbRecord {
  const db = getDatabase()
  if (!db[sector]) db[sector] = {}
  if (!db[sector][collection]) db[sector][collection] = []
  const now = Date.now()
  const record: DbRecord = { ...data, id: uid(collection), createdAt: now, updatedAt: now }
  db[sector][collection].unshift(record)
  saveDatabase(db)
  addLog("success", `${sector}/${collection}`, `Registro criado: ${record.id}`)
  return record
}

export function updateRecord(
  sector: string,
  collection: string,
  id: string,
  data: Record<string, unknown>,
): DbRecord | null {
  const db = getDatabase()
  const arr = db[sector]?.[collection]
  if (!arr) return null
  const idx = arr.findIndex((r) => r.id === id)
  if (idx === -1) return null
  arr[idx] = { ...arr[idx], ...data, id, updatedAt: Date.now() }
  saveDatabase(db)
  addLog("info", `${sector}/${collection}`, `Registro atualizado: ${id}`)
  return arr[idx]
}

/** Exclusao SEGURA: move o registro para a lixeira. */
export function softDeleteRecord(
  sector: string,
  collection: string,
  id: string,
  reason?: string,
): boolean {
  const db = getDatabase()
  const arr = db[sector]?.[collection]
  if (!arr) return false
  const idx = arr.findIndex((r) => r.id === id)
  if (idx === -1) return false
  const [record] = arr.splice(idx, 1)
  saveDatabase(db)

  const bin = getRecycleBin()
  const entry: RecycleEntry = {
    id: uid("bin"),
    deletedAt: Date.now(),
    sector,
    collection,
    path: collectionPath(sector, collection),
    record,
    reason,
  }
  bin.unshift(entry)
  writeRaw(LS_RECYCLE_KEY, bin)
  emit()
  addLog("warn", `${sector}/${collection}`, `Registro movido para a lixeira: ${id}`)
  return true
}

// ---------------------------------------------------------------------------
// RECYCLE BIN
// ---------------------------------------------------------------------------
export function getRecycleBin(): RecycleEntry[] {
  return readRaw<RecycleEntry[]>(LS_RECYCLE_KEY, [])
}

export function restoreFromBin(binId: string): boolean {
  const bin = getRecycleBin()
  const idx = bin.findIndex((e) => e.id === binId)
  if (idx === -1) return false
  const [entry] = bin.splice(idx, 1)
  writeRaw(LS_RECYCLE_KEY, bin)

  const db = getDatabase()
  if (!db[entry.sector]) db[entry.sector] = {}
  if (!db[entry.sector][entry.collection]) db[entry.sector][entry.collection] = []
  // Evita duplicidade.
  if (!db[entry.sector][entry.collection].some((r) => r.id === entry.record.id)) {
    db[entry.sector][entry.collection].unshift({ ...entry.record, updatedAt: Date.now() })
  }
  saveDatabase(db)
  addLog("success", `${entry.sector}/${entry.collection}`, `Registro restaurado: ${entry.record.id}`)
  return true
}

/** Purge apenas remove da lixeira (mantendo backup em log). */
export function purgeFromBin(binId: string): boolean {
  const bin = getRecycleBin()
  const idx = bin.findIndex((e) => e.id === binId)
  if (idx === -1) return false
  const [entry] = bin.splice(idx, 1)
  writeRaw(LS_RECYCLE_KEY, bin)
  emit()
  addLog("warn", `${entry.sector}/${entry.collection}`, `Item removido da lixeira (backup em log): ${entry.record.id}`)
  return true
}

// ---------------------------------------------------------------------------
// LOGS
// ---------------------------------------------------------------------------
export function getLogs(): LogEntry[] {
  return readRaw<LogEntry[]>(LS_LOGS_KEY, [])
}

export function addLog(level: LogEntry["level"], scope: string, message: string) {
  const logs = getLogs()
  logs.unshift({ id: uid("log"), ts: Date.now(), level, scope, message })
  writeRaw(LS_LOGS_KEY, logs.slice(0, 500))
  emit()
}

export function clearLogs() {
  writeRaw(LS_LOGS_KEY, [])
  emit()
}

// ---------------------------------------------------------------------------
// ESTATISTICAS
// ---------------------------------------------------------------------------
export function countAll(): { total: number; bySector: Record<string, number> } {
  const db = getDatabase()
  let total = 0
  const bySector: Record<string, number> = {}
  for (const sector of SECTORS) {
    let s = 0
    const cols = db[sector.key] ?? {}
    for (const arr of Object.values(cols)) s += arr.length
    bySector[sector.key] = s
    total += s
  }
  return { total, bySector }
}

// ---------------------------------------------------------------------------
// EXPORTAR / IMPORTAR (para JSON completo)
// ---------------------------------------------------------------------------
export function exportDatabase(): string {
  return JSON.stringify(
    { db: getDatabase(), recycle: getRecycleBin(), logs: getLogs(), exportedAt: Date.now() },
    null,
    2,
  )
}

export function importDatabase(json: string): boolean {
  try {
    const parsed = JSON.parse(json)
    if (parsed.db) writeRaw(LS_DB_KEY, parsed.db)
    if (parsed.recycle) writeRaw(LS_RECYCLE_KEY, parsed.recycle)
    if (parsed.logs) writeRaw(LS_LOGS_KEY, parsed.logs)
    emit()
    addLog("success", "sistema", "Banco de dados importado com sucesso.")
    return true
  } catch (e) {
    addLog("error", "sistema", `Falha ao importar: ${(e as Error).message}`)
    return false
  }
}

// ---------------------------------------------------------------------------
// SEED — popula dados de demonstracao na primeira execucao
// ---------------------------------------------------------------------------
export function seedIfEmpty() {
  const db = getDatabase()
  if (Object.keys(db).length > 0) return
  const now = Date.now()
  const seeded: Database = {
    "sistema-k": {
      metodos: [
        { id: uid("metodos"), createdAt: now, updatedAt: now, nome: "Metodo Forja K", descricao: "Ciclo de disciplina de 21 dias.", etapas: 3, status: "Ativo", tags: ["core", "disciplina"] },
        { id: uid("metodos"), createdAt: now, updatedAt: now, nome: "Protocolo Aurora", descricao: "Rotina matinal de alta performance.", etapas: 5, status: "Ativo", tags: ["rotina"] },
      ],
      pilares: [
        { id: uid("pilares"), createdAt: now, updatedAt: now, nome: "Corpo", descricao: "Saude fisica.", status: "Ativo" },
        { id: uid("pilares"), createdAt: now, updatedAt: now, nome: "Mente", descricao: "Clareza mental.", status: "Ativo" },
        { id: uid("pilares"), createdAt: now, updatedAt: now, nome: "Prosperidade", descricao: "Abundancia.", status: "Ativo" },
      ],
    },
    "k-tp": {
      treinos: [
        { id: uid("treinos"), createdAt: now, updatedAt: now, nome: "Push Pull Legs", objetivo: "Hipertrofia", nivel: "Intermediario", frequencia: 6, descricao: "Divisao classica.", tags: ["ppl"] },
      ],
      alunos: [
        { id: uid("alunos"), createdAt: now, updatedAt: now, nome: "Aluno Demo", email: "demo@korvil.app", telefone: "-", status: "Ativo" },
      ],
    },
    global: {
      usuarios: [
        { id: uid("usuarios"), createdAt: now, updatedAt: now, nome: "Criador KORVIL", usuario: "korvil", email: "criador@korvil.app", senha: "korvil", papel: "Criador", ativo: true },
      ],
      configuracoes: [
        { id: uid("config"), createdAt: now, updatedAt: now, nome: "tema", valor: "cyber-matrix", descricao: "Tema padrao da interface." },
      ],
    },
  }
  saveDatabase(clone(seeded))
  addLog("success", "sistema", "Banco de dados inicializado com dados de demonstracao.")
}
