"use client"

// ============================================================================
// KORVIL OS — SINCRONIZACAO GITHUB (REST API via fetch, sem Octokit)
// PAT e OPCIONAL. Sem PAT, tudo funciona local via fila persistida.
// ============================================================================

import { LS_PAT_KEY, LS_PREFIX, REPO_OWNER, REPO_NAME } from "./constants"
import { uid } from "./utils"
import { addLog } from "./db"

const LS_QUEUE_KEY = `${LS_PREFIX}::commit_queue`
const API = "https://api.github.com"

export interface CommitJob {
  id: string
  path: string
  content: string
  message: string
  status: "pending" | "committed" | "failed" | "local"
  createdAt: number
  updatedAt: number
  error?: string
  sha?: string
}

function isBrowser() {
  return typeof window !== "undefined"
}

// ---------------------------------------------------------------------------
// PAT
// ---------------------------------------------------------------------------
export function getPat(): string | null {
  if (!isBrowser()) return null
  return window.localStorage.getItem(LS_PAT_KEY)
}

export function setPat(pat: string) {
  if (!isBrowser()) return
  if (pat) window.localStorage.setItem(LS_PAT_KEY, pat)
  else window.localStorage.removeItem(LS_PAT_KEY)
  addLog(pat ? "success" : "info", "github", pat ? "PAT configurado." : "PAT removido.")
}

export function hasPat(): boolean {
  return !!getPat()
}

// ---------------------------------------------------------------------------
// FILA DE COMMITS
// ---------------------------------------------------------------------------
export function getQueue(): CommitJob[] {
  if (!isBrowser()) return []
  try {
    const raw = window.localStorage.getItem(LS_QUEUE_KEY)
    return raw ? (JSON.parse(raw) as CommitJob[]) : []
  } catch {
    return []
  }
}

function saveQueue(q: CommitJob[]) {
  if (!isBrowser()) return
  window.localStorage.setItem(LS_QUEUE_KEY, JSON.stringify(q))
  window.dispatchEvent(new CustomEvent("korvil-queue-change"))
}

export function onQueueChange(cb: () => void): () => void {
  if (!isBrowser()) return () => {}
  window.addEventListener("korvil-queue-change", cb)
  return () => window.removeEventListener("korvil-queue-change", cb)
}

export function enqueueCommit(path: string, content: string, message: string): CommitJob {
  const q = getQueue()
  const job: CommitJob = {
    id: uid("job"),
    path,
    content,
    message,
    status: hasPat() ? "pending" : "local",
    createdAt: Date.now(),
    updatedAt: Date.now(),
  }
  q.unshift(job)
  saveQueue(q)
  addLog("info", "github", `Commit enfileirado: ${path} (${job.status})`)
  return job
}

function updateJob(id: string, patch: Partial<CommitJob>) {
  const q = getQueue()
  const idx = q.findIndex((j) => j.id === id)
  if (idx === -1) return
  q[idx] = { ...q[idx], ...patch, updatedAt: Date.now() }
  saveQueue(q)
}

export function removeJob(id: string) {
  saveQueue(getQueue().filter((j) => j.id !== id))
}

export function clearQueue() {
  saveQueue([])
}

// ---------------------------------------------------------------------------
// PUSH via GitHub Contents API (cria/atualiza arquivo)
// ---------------------------------------------------------------------------
async function githubGetSha(path: string, pat: string): Promise<string | undefined> {
  try {
    const res = await fetch(
      `${API}/repos/${REPO_OWNER}/${REPO_NAME}/contents/${encodeURIComponent(path)}`,
      { headers: { Authorization: `Bearer ${pat}`, Accept: "application/vnd.github+json" } },
    )
    if (res.ok) {
      const data = await res.json()
      return data.sha as string
    }
  } catch {
    /* arquivo inexistente */
  }
  return undefined
}

function toBase64(str: string): string {
  if (isBrowser()) {
    return btoa(unescape(encodeURIComponent(str)))
  }
  return Buffer.from(str, "utf-8").toString("base64")
}

export async function pushJob(job: CommitJob): Promise<CommitJob> {
  const pat = getPat()
  if (!pat) {
    updateJob(job.id, { status: "local" })
    return { ...job, status: "local" }
  }
  try {
    const sha = await githubGetSha(job.path, pat)
    const res = await fetch(
      `${API}/repos/${REPO_OWNER}/${REPO_NAME}/contents/${encodeURIComponent(job.path)}`,
      {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${pat}`,
          Accept: "application/vnd.github+json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: job.message,
          content: toBase64(job.content),
          ...(sha ? { sha } : {}),
        }),
      },
    )
    if (!res.ok) {
      const errText = await res.text()
      updateJob(job.id, { status: "failed", error: `${res.status}: ${errText.slice(0, 160)}` })
      addLog("error", "github", `Falha no commit ${job.path}: ${res.status}`)
      return { ...job, status: "failed" }
    }
    const data = await res.json()
    updateJob(job.id, { status: "committed", sha: data.content?.sha })
    addLog("success", "github", `Commit enviado: ${job.path}`)
    return { ...job, status: "committed" }
  } catch (e) {
    updateJob(job.id, { status: "failed", error: (e as Error).message })
    addLog("error", "github", `Erro de rede no commit ${job.path}`)
    return { ...job, status: "failed" }
  }
}

/** Processa toda a fila pendente. Retorna resumo. */
export async function processQueue(): Promise<{ committed: number; failed: number; local: number }> {
  const q = getQueue()
  let committed = 0
  let failed = 0
  let local = 0
  for (const job of q.filter((j) => j.status === "pending" || j.status === "failed")) {
    const result = await pushJob(job)
    if (result.status === "committed") committed++
    else if (result.status === "failed") failed++
    else local++
  }
  return { committed, failed, local }
}

/** Valida o PAT chamando o endpoint /user. */
export async function validatePat(pat: string): Promise<{ ok: boolean; login?: string; error?: string }> {
  try {
    const res = await fetch(`${API}/user`, {
      headers: { Authorization: `Bearer ${pat}`, Accept: "application/vnd.github+json" },
    })
    if (!res.ok) return { ok: false, error: `Status ${res.status}` }
    const data = await res.json()
    return { ok: true, login: data.login }
  } catch (e) {
    return { ok: false, error: (e as Error).message }
  }
}
