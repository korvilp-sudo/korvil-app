// ============================================================================
// KORVIL OS — VALIDADOR AST / SINTAXE (leve, sem dependencias)
// Checa JSON, balanceamento de delimitadores e heuristicas de coerencia
// ANTES de qualquer commit. Garantia ZERO-FAIL.
// ============================================================================

export interface ValidationIssue {
  line: number
  column: number
  severity: "error" | "warning"
  message: string
}

export interface ValidationResult {
  ok: boolean
  issues: ValidationIssue[]
  language: "json" | "javascript" | "typescript" | "unknown"
}

function detectLanguage(path: string, content: string): ValidationResult["language"] {
  if (path.endsWith(".json")) return "json"
  if (path.endsWith(".ts") || path.endsWith(".tsx")) return "typescript"
  if (path.endsWith(".js") || path.endsWith(".jsx") || path.endsWith(".mjs")) return "javascript"
  const trimmed = content.trim()
  if (trimmed.startsWith("{") || trimmed.startsWith("[")) return "json"
  return "unknown"
}

function lineColFromIndex(content: string, index: number): { line: number; column: number } {
  let line = 1
  let column = 1
  for (let i = 0; i < index && i < content.length; i++) {
    if (content[i] === "\n") {
      line++
      column = 1
    } else {
      column++
    }
  }
  return { line, column }
}

// ---------------------------------------------------------------------------
// Validacao de JSON
// ---------------------------------------------------------------------------
function validateJson(content: string): ValidationIssue[] {
  const issues: ValidationIssue[] = []
  try {
    JSON.parse(content)
  } catch (e) {
    const msg = (e as Error).message
    const match = msg.match(/position (\d+)/)
    let pos = 0
    if (match) pos = parseInt(match[1], 10)
    const { line, column } = lineColFromIndex(content, pos)
    issues.push({ line, column, severity: "error", message: `JSON invalido: ${msg}` })
  }
  return issues
}

// ---------------------------------------------------------------------------
// Balanceamento de delimitadores (para JS/TS/JSON)
// Ignora conteudo dentro de strings e comentarios.
// ---------------------------------------------------------------------------
function validateBrackets(content: string): ValidationIssue[] {
  const issues: ValidationIssue[] = []
  const stack: { ch: string; index: number }[] = []
  const pairs: Record<string, string> = { ")": "(", "]": "[", "}": "{" }
  const openers = new Set(["(", "[", "{"])

  let inString: false | '"' | "'" | "`" = false
  let inLineComment = false
  let inBlockComment = false

  for (let i = 0; i < content.length; i++) {
    const ch = content[i]
    const prev = content[i - 1]
    const next = content[i + 1]

    if (inLineComment) {
      if (ch === "\n") inLineComment = false
      continue
    }
    if (inBlockComment) {
      if (ch === "*" && next === "/") {
        inBlockComment = false
        i++
      }
      continue
    }
    if (inString) {
      if (ch === inString && prev !== "\\") inString = false
      continue
    }

    if (ch === "/" && next === "/") {
      inLineComment = true
      i++
      continue
    }
    if (ch === "/" && next === "*") {
      inBlockComment = true
      i++
      continue
    }
    if (ch === '"' || ch === "'" || ch === "`") {
      inString = ch
      continue
    }

    if (openers.has(ch)) {
      stack.push({ ch, index: i })
    } else if (pairs[ch]) {
      const top = stack.pop()
      if (!top || top.ch !== pairs[ch]) {
        const { line, column } = lineColFromIndex(content, i)
        issues.push({ line, column, severity: "error", message: `Delimitador '${ch}' sem par correspondente.` })
      }
    }
  }

  if (inString) {
    issues.push({ line: content.split("\n").length, column: 1, severity: "error", message: `String nao fechada (${inString}).` })
  }
  if (inBlockComment) {
    issues.push({ line: content.split("\n").length, column: 1, severity: "error", message: "Comentario de bloco nao fechado (*/)." })
  }
  for (const leftover of stack) {
    const { line, column } = lineColFromIndex(content, leftover.index)
    issues.push({ line, column, severity: "error", message: `Delimitador '${leftover.ch}' nunca foi fechado.` })
  }
  return issues
}

// ---------------------------------------------------------------------------
// Heuristicas de coerencia para JS/TS
// ---------------------------------------------------------------------------
function validateHeuristics(content: string): ValidationIssue[] {
  const issues: ValidationIssue[] = []
  const lines = content.split("\n")
  lines.forEach((raw, idx) => {
    const line = raw.trim()
    if (/\bconsole\.log\s*\(/.test(line) && !/\[v0\]/.test(line)) {
      issues.push({ line: idx + 1, column: 1, severity: "warning", message: "console.log sem prefixo [v0]." })
    }
    if (/\b(var)\s+\w+/.test(line)) {
      issues.push({ line: idx + 1, column: 1, severity: "warning", message: "Uso de 'var' — prefira 'const'/'let'." })
    }
    if (/;;\s*$/.test(line)) {
      issues.push({ line: idx + 1, column: 1, severity: "warning", message: "Ponto-e-virgula duplicado." })
    }
    if (/\bTODO\b|\bFIXME\b/.test(line)) {
      issues.push({ line: idx + 1, column: 1, severity: "warning", message: "Marcador TODO/FIXME encontrado." })
    }
  })
  return issues
}

// ---------------------------------------------------------------------------
// API principal
// ---------------------------------------------------------------------------
export function validate(path: string, content: string): ValidationResult {
  const language = detectLanguage(path, content)
  const issues: ValidationIssue[] = []

  if (content.trim().length === 0) {
    return {
      ok: false,
      language,
      issues: [{ line: 1, column: 1, severity: "error", message: "Conteudo vazio." }],
    }
  }

  if (language === "json") {
    issues.push(...validateJson(content))
    if (issues.length === 0) issues.push(...validateBrackets(content))
  } else if (language === "javascript" || language === "typescript") {
    issues.push(...validateBrackets(content))
    issues.push(...validateHeuristics(content))
  } else {
    issues.push(...validateBrackets(content))
  }

  const ok = !issues.some((i) => i.severity === "error")
  return { ok, issues, language }
}

/** Formata o conteudo JSON caso valido. */
export function tryFormatJson(content: string): { ok: boolean; formatted?: string } {
  try {
    return { ok: true, formatted: JSON.stringify(JSON.parse(content), null, 2) }
  } catch {
    return { ok: false }
  }
}
