"use client"

// ============================================================================
// KORVIL OS — INTERPRETADOR DE INTENCOES DE VOZ
// Converte transcricoes em acoes concretas no banco de dados.
// ============================================================================

import { SECTORS, getSector } from "./constants"
import { normalize } from "./utils"
import { createRecord, countAll, getRecycleBin, getLogs, listRecords } from "./db"
import { defaultsFor } from "./coherence-rules"

export interface IntentResult {
  reply: string
  action?: string
  navigate?: string
}

function findSector(text: string) {
  const n = normalize(text)
  return SECTORS.find(
    (s) => n.includes(normalize(s.label)) || n.includes(normalize(s.key)) || n.includes(normalize(s.short)),
  )
}

function findCollection(text: string, sectorKey?: string) {
  const n = normalize(text)
  const sectors = sectorKey ? [getSector(sectorKey)!].filter(Boolean) : SECTORS
  for (const s of sectors) {
    for (const c of s.collections) {
      if (n.includes(normalize(c.label)) || n.includes(normalize(c.key))) {
        return { sector: s.key, collection: c.key, label: c.label, sectorLabel: s.label }
      }
    }
  }
  return null
}

export function interpret(transcript: string): IntentResult {
  const n = normalize(transcript)

  // --- Navegacao ---
  if (/(abrir|abra|ir para|va para|mostrar|mostra) .*(admin|painel|crud)/.test(n)) {
    return { reply: "Abrindo o painel administrativo.", navigate: "/admin", action: "nav" }
  }
  if (/(abrir|abra|ir para|va para|mostrar) .*(forge|forja|codigo|repo)/.test(n)) {
    return { reply: "Abrindo o Repo Forge.", navigate: "/forge", action: "nav" }
  }
  if (/(lixeira|reciclagem|recycle)/.test(n) && /(abrir|abra|ir|ver|mostrar)/.test(n)) {
    return { reply: "Abrindo a lixeira de seguranca.", navigate: "/admin/recycle-bin", action: "nav" }
  }
  if (/(usuarios|usuario|login index)/.test(n) && /(abrir|abra|ir|ver|gerenciar)/.test(n)) {
    return { reply: "Abrindo a gestao de usuarios.", navigate: "/admin/users", action: "nav" }
  }
  if (/(dados|data viewer|arvore|json)/.test(n) && /(abrir|abra|ir|ver|editar)/.test(n)) {
    return { reply: "Abrindo o visualizador de dados.", navigate: "/admin/data-viewer", action: "nav" }
  }
  if (/(dashboard|inicio|central|home)/.test(n) && /(abrir|abra|ir|voltar)/.test(n)) {
    return { reply: "Voltando ao dashboard central.", navigate: "/", action: "nav" }
  }

  // --- Estatisticas ---
  if (/(quantos|status|estatistica|resumo|relatorio)/.test(n)) {
    const { total } = countAll()
    const bin = getRecycleBin().length
    const logs = getLogs().length
    return {
      reply: `Temos ${total} registros ativos, ${bin} itens na lixeira e ${logs} eventos registrados. Sistema operacional, Chefe.`,
      action: "stats",
    }
  }

  // --- Criar registro ---
  if (/(criar|crie|cria|adicionar|adiciona|novo|nova|cadastrar)/.test(n)) {
    const target = findCollection(transcript)
    if (target) {
      // Extrai um possivel nome apos "chamado/chamada/nome"
      const nameMatch = transcript.match(/(?:chamad[oa]|nome|titulo|de)\s+(.+)$/i)
      const nome = nameMatch ? nameMatch[1].trim() : `Novo item por voz`
      const data = { ...defaultsFor(target.sector, target.collection), nome }
      createRecord(target.sector, target.collection, data)
      return {
        reply: `Registro criado em ${target.sectorLabel}, colecao ${target.label}, com o nome ${nome}. Gravado com sucesso, Chefe.`,
        action: "create",
        navigate: `/admin?sector=${target.sector}&collection=${target.collection}`,
      }
    }
    return {
      reply: "Entendi que quer criar algo, mas nao identifiquei a colecao. Diga por exemplo: criar treino chamado Full Body.",
      action: "create-fail",
    }
  }

  // --- Listar / contar colecao ---
  if (/(listar|liste|quantos tem|contar)/.test(n)) {
    const target = findCollection(transcript)
    if (target) {
      const count = listRecords(target.sector, target.collection).length
      return { reply: `A colecao ${target.label} de ${target.sectorLabel} tem ${count} registros.`, action: "count" }
    }
    const s = findSector(transcript)
    if (s) return { reply: `O setor ${s.label} tem ${s.collections.length} colecoes disponiveis.`, action: "count" }
  }

  // --- Ajuda ---
  if (/(ajuda|o que voce faz|comandos|help)/.test(n)) {
    return {
      reply:
        "Posso navegar pelo sistema, criar registros por voz, informar estatisticas e abrir a lixeira. Experimente: criar meta chamada Liberdade Financeira.",
      action: "help",
    }
  }

  // --- Saudacoes ---
  if (/(ola|oi|bom dia|boa tarde|boa noite|e ai)/.test(n)) {
    return { reply: "Ola, Chefe. KORVIL OS pronto para operar. O que vamos forjar hoje?", action: "greet" }
  }

  return {
    reply: "Nao captei uma acao valida. Diga 'ajuda' para ver o que eu consigo fazer, Chefe.",
    action: "unknown",
  }
}
