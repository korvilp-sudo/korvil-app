"use client"

import * as React from "react"
import { cn } from "@/lib/utils"

interface DropdownItem {
  key: string
  label: React.ReactNode
  onSelect: () => void
  danger?: boolean
}

export function Dropdown({
  trigger,
  items,
  align = "end",
}: {
  trigger: React.ReactNode
  items: DropdownItem[]
  align?: "start" | "end"
}) {
  const [open, setOpen] = React.useState(false)
  const ref = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener("mousedown", onClick)
    return () => document.removeEventListener("mousedown", onClick)
  }, [])

  return (
    <div className="relative inline-flex" ref={ref}>
      <button onClick={() => setOpen((o) => !o)} aria-haspopup="menu" aria-expanded={open}>
        {trigger}
      </button>
      {open && (
        <div
          role="menu"
          className={cn(
            "absolute top-full z-50 mt-1 min-w-40 rounded-md border border-border bg-popover p-1 kai-glow",
            align === "end" ? "right-0" : "left-0",
          )}
        >
          {items.map((item) => (
            <button
              key={item.key}
              role="menuitem"
              onClick={() => {
                item.onSelect()
                setOpen(false)
              }}
              className={cn(
                "flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-xs transition-colors",
                item.danger
                  ? "text-destructive hover:bg-destructive/15"
                  : "text-foreground hover:bg-secondary",
              )}
            >
              {item.label}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
