"use client"

import * as React from "react"
import { cn } from "@/lib/utils"

export function Tooltip({
  label,
  children,
  className,
}: {
  label: string
  children: React.ReactNode
  className?: string
}) {
  return (
    <span className={cn("group/tt relative inline-flex", className)}>
      {children}
      <span
        role="tooltip"
        className="pointer-events-none absolute bottom-full left-1/2 z-50 mb-1.5 -translate-x-1/2 whitespace-nowrap rounded-md border border-border bg-popover px-2 py-1 text-[0.65rem] text-popover-foreground opacity-0 transition-opacity group-hover/tt:opacity-100"
      >
        {label}
      </span>
    </span>
  )
}
