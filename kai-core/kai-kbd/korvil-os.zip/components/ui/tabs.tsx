"use client"

import * as React from "react"
import { cn } from "@/lib/utils"

interface Tab {
  key: string
  label: React.ReactNode
}

export function Tabs({
  tabs,
  active,
  onChange,
  className,
}: {
  tabs: Tab[]
  active: string
  onChange: (key: string) => void
  className?: string
}) {
  return (
    <div
      role="tablist"
      className={cn("flex flex-wrap items-center gap-1 rounded-lg border border-border bg-card/50 p-1", className)}
    >
      {tabs.map((t) => {
        const isActive = t.key === active
        return (
          <button
            key={t.key}
            role="tab"
            aria-selected={isActive}
            onClick={() => onChange(t.key)}
            className={cn(
              "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
              isActive
                ? "bg-primary text-primary-foreground kai-glow"
                : "text-muted-foreground hover:bg-secondary hover:text-foreground",
            )}
          >
            {t.label}
          </button>
        )
      })}
    </div>
  )
}
