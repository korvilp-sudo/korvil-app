"use client"

import * as React from "react"
import { CheckCircle2, AlertTriangle, Info, XCircle, X } from "lucide-react"
import { cn } from "@/lib/utils"

type ToastKind = "success" | "error" | "warn" | "info"

interface ToastItem {
  id: string
  kind: ToastKind
  message: string
}

interface ToastContextValue {
  toast: (message: string, kind?: ToastKind) => void
}

const ToastContext = React.createContext<ToastContextValue | null>(null)

export function useToast() {
  const ctx = React.useContext(ToastContext)
  if (!ctx) return { toast: () => {} }
  return ctx
}

const icons: Record<ToastKind, React.ReactNode> = {
  success: <CheckCircle2 className="size-4 text-[oklch(0.8_0.14_150)]" />,
  error: <XCircle className="size-4 text-destructive" />,
  warn: <AlertTriangle className="size-4 text-accent" />,
  info: <Info className="size-4 text-primary" />,
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = React.useState<ToastItem[]>([])

  const remove = React.useCallback((id: string) => {
    setItems((prev) => prev.filter((t) => t.id !== id))
  }, [])

  const toast = React.useCallback(
    (message: string, kind: ToastKind = "info") => {
      const id = Math.random().toString(36).slice(2)
      setItems((prev) => [...prev, { id, kind, message }])
      setTimeout(() => remove(id), 4200)
    },
    [remove],
  )

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="fixed bottom-4 right-4 z-[100] flex w-full max-w-xs flex-col gap-2">
        {items.map((t) => (
          <div
            key={t.id}
            role="status"
            className={cn(
              "flex items-start gap-2 rounded-lg border border-border bg-card p-3 text-xs kai-glow animate-in",
            )}
          >
            <span className="mt-0.5">{icons[t.kind]}</span>
            <p className="flex-1 leading-relaxed text-card-foreground">{t.message}</p>
            <button
              onClick={() => remove(t.id)}
              className="text-muted-foreground hover:text-foreground"
              aria-label="Fechar notificacao"
            >
              <X className="size-3.5" />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}
