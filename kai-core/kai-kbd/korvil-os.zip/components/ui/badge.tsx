import * as React from "react"
import { cn } from "@/lib/utils"

type Variant = "default" | "outline" | "success" | "warn" | "danger" | "accent"

const variants: Record<Variant, string> = {
  default: "border-border bg-secondary text-secondary-foreground",
  outline: "border-border bg-transparent text-foreground",
  success: "border-[oklch(0.7_0.14_150_/_40%)] bg-[oklch(0.7_0.14_150_/_15%)] text-[oklch(0.8_0.14_150)]",
  warn: "border-[oklch(0.8_0.15_75_/_40%)] bg-[oklch(0.8_0.15_75_/_15%)] text-accent",
  danger: "border-destructive/40 bg-destructive/15 text-destructive",
  accent: "border-primary/40 bg-primary/15 text-primary",
}

export function Badge({
  className,
  variant = "default",
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & { variant?: Variant }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[0.65rem] font-medium uppercase tracking-wide",
        variants[variant],
        className,
      )}
      {...props}
    />
  )
}
