"use client"

import { useState } from "react"
import type { FieldSchema, CollectionSchema } from "@/lib/constants"
import { Input, Textarea, Select } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { validateRecord, defaultsFor } from "@/lib/coherence-rules"
import { cn } from "@/lib/utils"

export function UniversalForm({
  sectorKey,
  collection,
  initial,
  onSubmit,
  onCancel,
  submitLabel = "Salvar",
}: {
  sectorKey: string
  collection: CollectionSchema
  initial?: Record<string, any>
  onSubmit: (values: Record<string, any>) => void
  onCancel?: () => void
  submitLabel?: string
}) {
  const [values, setValues] = useState<Record<string, any>>(() => {
    const base = defaultsFor(sectorKey, collection.key)
    if (initial) for (const f of collection.fields) if (initial[f.key] !== undefined) base[f.key] = initial[f.key]
    return base
  })
  const [errors, setErrors] = useState<Record<string, string>>({})

  function set(key: string, value: any) {
    setValues((v) => ({ ...v, [key]: value }))
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const result = validateRecord(sectorKey, collection.key, values)
    if (!result.ok) {
      const map: Record<string, string> = {}
      for (const issue of result.issues) map[issue.field] = issue.message
      setErrors(map)
      return
    }
    setErrors({})
    onSubmit(values)
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-4">
      <div className="grid gap-4 sm:grid-cols-2">
        {collection.fields.map((f) => (
          <Field
            key={f.key}
            field={f}
            value={values[f.key]}
            error={errors[f.key]}
            onChange={(val) => set(f.key, val)}
            full={f.type === "textarea"}
          />
        ))}
      </div>
      <div className="flex items-center justify-end gap-2 border-t border-border pt-4">
        {onCancel && (
          <Button type="button" variant="ghost" onClick={onCancel}>
            Cancelar
          </Button>
        )}
        <Button type="submit">{submitLabel}</Button>
      </div>
    </form>
  )
}

function Field({
  field,
  value,
  error,
  onChange,
  full,
}: {
  field: FieldSchema
  value: any
  error?: string
  onChange: (v: any) => void
  full?: boolean
}) {
  return (
    <div className={cn("grid gap-1.5", full && "sm:col-span-2")}>
      <label className="font-mono text-xs uppercase tracking-wide text-muted-foreground">
        {field.label}
        {field.required && <span className="ml-1 text-destructive">*</span>}
      </label>
      {field.type === "textarea" ? (
        <Textarea value={value ?? ""} onChange={(e) => onChange(e.target.value)} placeholder={field.placeholder} rows={3} />
      ) : field.type === "select" ? (
        <Select value={value ?? ""} onChange={(e) => onChange(e.target.value)}>
          <option value="">— selecionar —</option>
          {field.options?.map((o) => (
            <option key={o} value={o}>
              {o}
            </option>
          ))}
        </Select>
      ) : field.type === "boolean" ? (
        <label className="flex items-center gap-2 py-1.5">
          <input
            type="checkbox"
            checked={!!value}
            onChange={(e) => onChange(e.target.checked)}
            className="size-4 accent-[var(--primary)]"
          />
          <span className="text-sm text-foreground">{value ? "Sim" : "Nao"}</span>
        </label>
      ) : field.type === "color" ? (
        <div className="flex items-center gap-2">
          <input
            type="color"
            value={value || "#22d3ee"}
            onChange={(e) => onChange(e.target.value)}
            className="size-9 cursor-pointer rounded-md border border-input bg-transparent"
          />
          <Input value={value ?? ""} onChange={(e) => onChange(e.target.value)} placeholder="#22d3ee" />
        </div>
      ) : field.type === "tags" ? (
        <TagsInput value={Array.isArray(value) ? value : []} onChange={onChange} placeholder={field.placeholder} />
      ) : (
        <Input
          type={field.type === "number" ? "number" : field.type === "date" ? "date" : field.type === "password" ? "password" : field.type === "email" ? "email" : "text"}
          value={value ?? ""}
          onChange={(e) => onChange(field.type === "number" ? Number(e.target.value) : e.target.value)}
          placeholder={field.placeholder}
        />
      )}
      {error && <span className="font-mono text-[11px] text-destructive">{error}</span>}
    </div>
  )
}

function TagsInput({
  value,
  onChange,
  placeholder,
}: {
  value: string[]
  onChange: (v: string[]) => void
  placeholder?: string
}) {
  const [draft, setDraft] = useState("")
  function add() {
    const t = draft.trim()
    if (t && !value.includes(t)) onChange([...value, t])
    setDraft("")
  }
  return (
    <div className="rounded-md border border-input bg-background/60 p-2">
      <div className="mb-2 flex flex-wrap gap-1.5">
        {value.map((tag) => (
          <button
            key={tag}
            type="button"
            onClick={() => onChange(value.filter((t) => t !== tag))}
            className="rounded-full bg-primary/15 px-2 py-0.5 font-mono text-[11px] text-primary hover:bg-destructive/20 hover:text-destructive"
          >
            {tag} ×
          </button>
        ))}
      </div>
      <input
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            if (e.nativeEvent.isComposing || e.keyCode === 229) return
            e.preventDefault()
            add()
          }
        }}
        placeholder={placeholder}
        className="w-full bg-transparent font-mono text-sm text-foreground outline-none placeholder:text-muted-foreground/60"
      />
    </div>
  )
}
