"use client"

import { useExp } from "@/hooks/use-exp"
import { cn } from "@/lib/utils"

const TITLES = ["Iniciado", "Aprendiz", "Operador", "Forjador", "Arquiteto", "Mestre", "Lenda KORVIL"]

function titleFor(level: number): string {
  return TITLES[Math.min(TITLES.length - 1, Math.floor((level - 1) / 3))]
}

export function ExpBar({ compact = false, className }: { compact?: boolean; className?: string }) {
  const { level, xp, needed, percent } = useExp()
  const title = titleFor(level)

  if (compact) {
    return (
      <div className={cn("flex items-center gap-2", className)}>
        <span className="font-mono text-xs font-bold text-primary kai-text-glow">Lv{level}</span>
        <div className="h-1.5 w-24 overflow-hidden rounded-full bg-secondary">
          <div className="h-full rounded-full bg-primary transition-all duration-500" style={{ width: `${percent}%` }} />
        </div>
      </div>
    )
  }

  return (
    <div className={cn("rounded-lg border border-border bg-card/60 p-3 kai-glow", className)}>
      <div className="mb-1.5 flex items-center justify-between">
        <div className="flex items-baseline gap-2">
          <span className="font-mono text-lg font-bold text-primary kai-text-glow">Lv {level}</span>
          <span className="text-xs text-muted-foreground">{title}</span>
        </div>
        <span className="font-mono text-xs text-muted-foreground">{xp} EXP</span>
      </div>
      <div className="h-2.5 w-full overflow-hidden rounded-full bg-secondary">
        <div
          className="h-full rounded-full bg-gradient-to-r from-primary to-accent transition-all duration-700"
          style={{ width: `${percent}%` }}
        />
      </div>
      <div className="mt-1 text-right font-mono text-[10px] text-muted-foreground">
        {xp} / {needed} para o proximo nivel
      </div>
    </div>
  )
}
