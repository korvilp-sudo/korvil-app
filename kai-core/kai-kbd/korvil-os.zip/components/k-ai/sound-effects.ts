"use client"

// ============================================================================
// KORVIL OS — SINTETIZADOR DE EFEITOS SONOROS (Web Audio API)
// Sons gerados proceduralmente. Zero arquivos, zero rede.
// ============================================================================

let ctx: AudioContext | null = null

function ensureCtx(): AudioContext | null {
  if (typeof window === "undefined") return null
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    if (!AC) return null
    ctx = new AC()
  }
  if (ctx.state === "suspended") void ctx.resume()
  return ctx
}

/** Inicializa o contexto (chamar em resposta a um gesto do usuario). */
export function initAudio() {
  const c = ensureCtx()
  if (c && c.state === "suspended") void c.resume()
}

interface ToneOptions {
  freq: number
  duration?: number
  type?: OscillatorType
  gain?: number
  slideTo?: number
  delay?: number
}

function tone({ freq, duration = 0.14, type = "sine", gain = 0.16, slideTo, delay = 0 }: ToneOptions) {
  const c = ensureCtx()
  if (!c) return
  const now = c.currentTime + delay
  const osc = c.createOscillator()
  const g = c.createGain()
  osc.type = type
  osc.frequency.setValueAtTime(freq, now)
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, now + duration)
  g.gain.setValueAtTime(0.0001, now)
  g.gain.exponentialRampToValueAtTime(gain, now + 0.012)
  g.gain.exponentialRampToValueAtTime(0.0001, now + duration)
  osc.connect(g)
  g.connect(c.destination)
  osc.start(now)
  osc.stop(now + duration + 0.02)
}

export const SFX = {
  click() {
    tone({ freq: 620, duration: 0.06, type: "square", gain: 0.08 })
  },
  confirm() {
    tone({ freq: 520, duration: 0.09, type: "triangle" })
    tone({ freq: 780, duration: 0.12, type: "triangle", delay: 0.08 })
  },
  success() {
    tone({ freq: 523, duration: 0.1, type: "triangle" })
    tone({ freq: 659, duration: 0.1, type: "triangle", delay: 0.09 })
    tone({ freq: 880, duration: 0.16, type: "triangle", delay: 0.18 })
  },
  error() {
    tone({ freq: 330, duration: 0.16, type: "sawtooth", gain: 0.12, slideTo: 140 })
  },
  wake() {
    tone({ freq: 440, duration: 0.1, type: "sine", slideTo: 880 })
    tone({ freq: 880, duration: 0.14, type: "sine", delay: 0.1, slideTo: 1320 })
  },
  listen() {
    tone({ freq: 700, duration: 0.08, type: "sine", gain: 0.09 })
  },
  levelUp() {
    ;[523, 659, 784, 1046].forEach((f, i) =>
      tone({ freq: f, duration: 0.14, type: "triangle", delay: i * 0.1 }),
    )
  },
  delete() {
    tone({ freq: 260, duration: 0.12, type: "sawtooth", gain: 0.1, slideTo: 120 })
  },
  restore() {
    tone({ freq: 400, duration: 0.1, type: "sine", slideTo: 700 })
    tone({ freq: 700, duration: 0.12, type: "sine", delay: 0.09, slideTo: 1000 })
  },
  boot() {
    ;[196, 262, 330, 392, 523].forEach((f, i) =>
      tone({ freq: f, duration: 0.18, type: "triangle", delay: i * 0.08, gain: 0.1 }),
    )
  },
  commit() {
    tone({ freq: 600, duration: 0.07, type: "square", gain: 0.08 })
    tone({ freq: 900, duration: 0.1, type: "square", gain: 0.08, delay: 0.06 })
  },
}

export type SfxName = keyof typeof SFX

/** Atalho seguro: dispara um efeito sonoro por nome. */
export function playSound(name: SfxName) {
  try {
    SFX[name]?.()
  } catch {
    /* audio indisponivel */
  }
}
