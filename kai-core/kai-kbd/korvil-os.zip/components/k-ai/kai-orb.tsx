"use client"

import { cn } from "@/lib/utils"

export type OrbState = "idle" | "listening" | "thinking" | "speaking" | "confirming" | "error"

const STATE_COLOR: Record<OrbState, string> = {
  idle: "oklch(0.82 0.16 195)",
  listening: "oklch(0.82 0.16 195)",
  thinking: "oklch(0.8 0.15 75)",
  speaking: "oklch(0.7 0.14 150)",
  confirming: "oklch(0.8 0.15 75)",
  error: "oklch(0.62 0.23 20)",
}

export function KaiOrb({
  state = "idle",
  size = 72,
  level = 0,
  onClick,
  className,
}: {
  state?: OrbState
  size?: number
  level?: number
  onClick?: () => void
  className?: string
}) {
  const color = STATE_COLOR[state]
  const pulsing = state === "listening" || state === "confirming"
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={`K-AI: ${state}`}
      className={cn(
        "relative grid place-items-center rounded-full transition-transform active:scale-95",
        pulsing && "kai-pulse",
        className,
      )}
      style={{ width: size, height: size }}
    >
      <span
        className="absolute inset-0 rounded-full opacity-40 blur-md"
        style={{ background: color }}
        aria-hidden
      />
      <span
        className="absolute inset-1 rounded-full"
        style={{
          background: `radial-gradient(circle at 30% 25%, ${color}, oklch(0.16 0.02 250) 78%)`,
          boxShadow: `inset 0 0 18px -4px ${color}, 0 0 26px -6px ${color}`,
        }}
        aria-hidden
      />
      <span
        className={cn(
          "absolute inset-2 rounded-full border-2",
          state === "thinking" && "animate-spin",
        )}
        style={{ borderColor: `${color}`, borderTopColor: "transparent", opacity: 0.6 }}
        aria-hidden
      />
      <span className="relative z-10 font-mono text-xs font-bold tracking-tight" style={{ color }}>
        {level > 0 ? `Lv${level}` : "K-AI"}
      </span>
    </button>
  )
}
