"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { useRouter } from "next/navigation"
import { KaiOrb, type OrbState } from "./kai-orb"
import { useVoice } from "@/hooks/use-voice"
import { useExp } from "@/hooks/use-exp"
import { interpret } from "@/lib/voice-intents"
import { playSound } from "./sound-effects"
import { cn } from "@/lib/utils"
import { Mic, MicOff, Send, X, Radio } from "lucide-react"

export function KaiHud() {
  const router = useRouter()
  const { level, gain } = useExp()
  const [open, setOpen] = useState(false)
  const [textInput, setTextInput] = useState("")
  const speakingRef = useRef(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const logEndRef = useRef<HTMLDivElement>(null)

  const speak = useCallback((text: string) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return
    try {
      window.speechSynthesis.cancel()
      const u = new SpeechSynthesisUtterance(text)
      u.lang = "pt-BR"
      u.rate = 1.05
      u.pitch = 0.9
      u.onstart = () => {
        speakingRef.current = true
        setIsSpeaking(true)
      }
      u.onend = () => {
        speakingRef.current = false
        setIsSpeaking(false)
      }
      window.speechSynthesis.speak(u)
    } catch {
      /* noop */
    }
  }, [])

  const handleCommand = useCallback(
    async (transcript: string) => {
      const result = interpret(transcript)
      if (result.action === "create") gain(25)
      else if (result.action === "nav") gain(4)
      else gain(2)

      if (result.navigate) {
        setTimeout(() => router.push(result.navigate!), 400)
      }
      playSound("success")
      return result.reply
    },
    [gain, router],
  )

  const voice = useVoice({
    onSpeak: speak,
    onCommand: handleCommand,
    onWake: () => {
      playSound("wake")
      setOpen(true)
    },
    onListen: () => playSound("listen"),
  })

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [voice.log])

  const orbState: OrbState = isSpeaking
    ? "speaking"
    : voice.state === "listening"
      ? "listening"
      : voice.state === "awaiting-confirm"
        ? "confirming"
        : voice.state === "processing"
          ? "thinking"
          : voice.enabled
            ? "listening"
            : "idle"

  function submitText(e: React.FormEvent) {
    e.preventDefault()
    const t = textInput.trim()
    if (!t) return
    voice.sendText(t)
    setTextInput("")
    playSound("click")
  }

  return (
    <>
      {/* Orbe flutuante */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
        {open && (
          <div className="w-[min(92vw,340px)] overflow-hidden rounded-xl border border-border bg-card/95 backdrop-blur-md kai-glow kai-scanline">
            <header className="flex items-center justify-between border-b border-border bg-secondary/50 px-3 py-2">
              <div className="flex items-center gap-2">
                <Radio className={cn("size-4 text-primary", voice.enabled && "animate-pulse")} />
                <span className="font-mono text-xs font-bold uppercase tracking-wider text-primary">K-AI Console</span>
              </div>
              <button onClick={() => setOpen(false)} aria-label="Fechar" className="text-muted-foreground hover:text-foreground">
                <X className="size-4" />
              </button>
            </header>

            <div className="flex items-center justify-between gap-2 border-b border-border px-3 py-2 text-[11px]">
              <span className="font-mono text-muted-foreground">
                Estado: <span className="text-primary">{voice.state}</span>
              </span>
              {voice.countdown > 0 && (
                <span className="font-mono text-accent kai-flicker">ativo {voice.countdown}s</span>
              )}
              {!voice.supported && <span className="text-destructive">sem microfone</span>}
            </div>

            <div className="kai-scroll max-h-56 space-y-2 overflow-y-auto px-3 py-3">
              {voice.log.length === 0 && (
                <p className="py-6 text-center text-xs text-muted-foreground text-balance">
                  {'Diga "K-AI" ou "Modo Forja" para me ativar. Voce tambem pode digitar comandos abaixo.'}
                </p>
              )}
              {voice.log.map((item) => (
                <div
                  key={item.id}
                  className={cn(
                    "max-w-[85%] rounded-lg px-2.5 py-1.5 text-xs",
                    item.role === "kai"
                      ? "bg-primary/10 text-foreground border border-primary/20"
                      : "ml-auto bg-secondary text-secondary-foreground",
                  )}
                >
                  {item.text}
                </div>
              ))}
              <div ref={logEndRef} />
            </div>

            <form onSubmit={submitText} className="flex items-center gap-2 border-t border-border p-2">
              <input
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && (e.nativeEvent.isComposing || e.keyCode === 229)) e.preventDefault()
                }}
                placeholder="Digite um comando..."
                className="h-8 flex-1 rounded-md border border-input bg-background px-2 text-xs outline-none focus:ring-2 focus:ring-ring"
              />
              <button type="submit" aria-label="Enviar" className="grid size-8 place-items-center rounded-md bg-primary text-primary-foreground">
                <Send className="size-3.5" />
              </button>
              <button
                type="button"
                onClick={voice.toggle}
                aria-label={voice.enabled ? "Desligar microfone" : "Ligar microfone"}
                className={cn(
                  "grid size-8 place-items-center rounded-md border border-border",
                  voice.enabled ? "bg-primary/20 text-primary" : "bg-secondary text-muted-foreground",
                )}
              >
                {voice.enabled ? <Mic className="size-3.5" /> : <MicOff className="size-3.5" />}
              </button>
            </form>
          </div>
        )}

        <KaiOrb
          state={orbState}
          level={level}
          size={64}
          onClick={() => {
            setOpen((o) => !o)
            playSound("click")
          }}
        />
      </div>
    </>
  )
}
