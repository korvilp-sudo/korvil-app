"use client"

// ============================================================================
// KORVIL OS — HOOK DO ASSISTENTE DE VOZ K-AI
// Web Speech API (SpeechRecognition). Deteccao de palavra de ativacao,
// desambiguacao "Caio", timer de 5s e roteamento de intencoes.
// ============================================================================

import { useCallback, useEffect, useRef, useState } from "react"
import { WAKE_WORDS, VOICE_TIMER_SECONDS } from "@/lib/constants"
import { normalize } from "@/lib/utils"
import { addLog } from "@/lib/db"

export type VoiceState = "idle" | "listening" | "awaiting-confirm" | "active" | "processing"

export interface VoiceLogItem {
  id: string
  ts: number
  role: "user" | "kai"
  text: string
}

interface UseVoiceOptions {
  onSpeak: (text: string) => void
  onCommand: (transcript: string) => Promise<string> | string
  onWake?: () => void
  onListen?: () => void
}

type SpeechRecognitionLike = {
  lang: string
  continuous: boolean
  interimResults: boolean
  start: () => void
  stop: () => void
  abort: () => void
  onresult: ((e: unknown) => void) | null
  onerror: ((e: unknown) => void) | null
  onend: (() => void) | null
}

function getRecognition(): SpeechRecognitionLike | null {
  if (typeof window === "undefined") return null
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRecognitionLike
    webkitSpeechRecognition?: new () => SpeechRecognitionLike
  }
  const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition
  if (!Ctor) return null
  return new Ctor()
}

export function useVoice({ onSpeak, onCommand, onWake, onListen }: UseVoiceOptions) {
  const [supported, setSupported] = useState(false)
  const [enabled, setEnabled] = useState(false)
  const [state, setState] = useState<VoiceState>("idle")
  const [transcript, setTranscript] = useState("")
  const [countdown, setCountdown] = useState(0)
  const [log, setLog] = useState<VoiceLogItem[]>([])

  const recRef = useRef<SpeechRecognitionLike | null>(null)
  const stateRef = useRef<VoiceState>("idle")
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const enabledRef = useRef(false)

  stateRef.current = state
  enabledRef.current = enabled

  const pushLog = useCallback((role: VoiceLogItem["role"], text: string) => {
    setLog((prev) => [...prev.slice(-40), { id: Math.random().toString(36).slice(2), ts: Date.now(), role, text }])
  }, [])

  const say = useCallback(
    (text: string) => {
      onSpeak(text)
      pushLog("kai", text)
    },
    [onSpeak, pushLog],
  )

  const clearTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current)
      timerRef.current = null
    }
    setCountdown(0)
  }, [])

  const startTimer = useCallback(() => {
    clearTimer()
    setCountdown(VOICE_TIMER_SECONDS)
    timerRef.current = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          clearTimer()
          setState("listening")
          return 0
        }
        return c - 1
      })
    }, 1000)
  }, [clearTimer])

  // Processa uma frase reconhecida de acordo com o estado da maquina.
  const handleTranscript = useCallback(
    async (raw: string) => {
      const text = raw.trim()
      if (!text) return
      const norm = normalize(text)
      setTranscript(text)
      pushLog("user", text)

      const current = stateRef.current

      // Aguardando confirmacao apos ouvir "Caio".
      if (current === "awaiting-confirm") {
        if (/(criador|chefe|voce|voc[eê]|sim|era eu|fui eu|kai|k-ai)/.test(norm)) {
          setState("active")
          say("Certo, Chefe, o que quer fazer?")
          onWake?.()
          startTimer()
        } else {
          setState("listening")
          say("Entendido, seguindo em modo de escuta.")
        }
        return
      }

      // Modo ativo: executa comando.
      if (current === "active") {
        clearTimer()
        setState("processing")
        onListen?.()
        try {
          const response = await onCommand(text)
          say(response)
        } catch (e) {
          say("Tive um problema ao executar. Pode repetir?")
          addLog("error", "voz", `Erro ao processar comando: ${(e as Error).message}`)
        }
        setState("listening")
        return
      }

      // Modo de escuta: procura palavra de ativacao.
      const hitCaio = /\bcaio\b/.test(norm)
      const hitWake = WAKE_WORDS.some((w) => norm.includes(w))

      if (hitCaio && !/\bkai\b|\bk-ai\b/.test(norm)) {
        setState("awaiting-confirm")
        say("Me chamou, Criador, ou chamou Caio?")
        onWake?.()
        return
      }

      if (hitWake) {
        setState("active")
        say("Certo, Chefe, o que quer fazer?")
        onWake?.()
        startTimer()
        return
      }
    },
    [pushLog, say, onWake, onListen, onCommand, startTimer, clearTimer],
  )

  // Configura o reconhecimento.
  useEffect(() => {
    const rec = getRecognition()
    if (!rec) {
      setSupported(false)
      return
    }
    setSupported(true)
    rec.lang = "pt-BR"
    rec.continuous = true
    rec.interimResults = false

    rec.onresult = (e: unknown) => {
      const ev = e as { results: ArrayLike<ArrayLike<{ transcript: string }>>; resultIndex: number }
      const last = ev.results[ev.results.length - 1]
      if (last && last[0]) void handleTranscript(last[0].transcript)
    }
    rec.onerror = (e: unknown) => {
      const err = (e as { error?: string }).error
      if (err === "not-allowed" || err === "service-not-allowed") {
        setEnabled(false)
        setState("idle")
        addLog("error", "voz", "Permissao de microfone negada.")
      }
    }
    rec.onend = () => {
      // Reinicia se ainda habilitado (continuous morre sozinho em alguns browsers).
      if (enabledRef.current) {
        try {
          rec.start()
        } catch {
          /* ja iniciado */
        }
      }
    }
    recRef.current = rec
    return () => {
      try {
        rec.abort()
      } catch {
        /* noop */
      }
    }
  }, [handleTranscript])

  const start = useCallback(() => {
    if (!recRef.current) return
    setEnabled(true)
    setState("listening")
    try {
      recRef.current.start()
      addLog("info", "voz", "Assistente de voz ativado.")
    } catch {
      /* ja iniciado */
    }
  }, [])

  const stop = useCallback(() => {
    setEnabled(false)
    setState("idle")
    clearTimer()
    try {
      recRef.current?.stop()
    } catch {
      /* noop */
    }
    addLog("info", "voz", "Assistente de voz desativado.")
  }, [clearTimer])

  const toggle = useCallback(() => {
    if (enabled) stop()
    else start()
  }, [enabled, start, stop])

  // Permite disparar comandos por texto (fallback sem microfone).
  const sendText = useCallback(
    (text: string) => {
      if (stateRef.current === "idle") setState("listening")
      void handleTranscript(text)
    },
    [handleTranscript],
  )

  return {
    supported,
    enabled,
    state,
    transcript,
    countdown,
    log,
    start,
    stop,
    toggle,
    sendText,
  }
}
