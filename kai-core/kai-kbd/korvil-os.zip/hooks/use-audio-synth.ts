"use client"

// ============================================================================
// KORVIL OS — SINTETIZADOR DE VOZ (Web Speech API - SpeechSynthesis)
// Fala pt-BR com fallback silencioso quando indisponivel.
// ============================================================================

import { useCallback, useEffect, useRef, useState } from "react"

export interface SpeakOptions {
  rate?: number
  pitch?: number
  volume?: number
}

export function useAudioSynth() {
  const [supported, setSupported] = useState(false)
  const [speaking, setSpeaking] = useState(false)
  const voiceRef = useRef<SpeechSynthesisVoice | null>(null)

  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return
    setSupported(true)

    function pickVoice() {
      const voices = window.speechSynthesis.getVoices()
      const pt = voices.find((v) => /pt[-_]?BR/i.test(v.lang)) || voices.find((v) => /^pt/i.test(v.lang))
      voiceRef.current = pt || voices[0] || null
    }
    pickVoice()
    window.speechSynthesis.onvoiceschanged = pickVoice
    return () => {
      window.speechSynthesis.onvoiceschanged = null
    }
  }, [])

  const speak = useCallback(
    (text: string, opts: SpeakOptions = {}) => {
      if (typeof window === "undefined" || !("speechSynthesis" in window)) return
      try {
        window.speechSynthesis.cancel()
        const u = new SpeechSynthesisUtterance(text)
        u.lang = "pt-BR"
        u.rate = opts.rate ?? 1.02
        u.pitch = opts.pitch ?? 1.0
        u.volume = opts.volume ?? 1.0
        if (voiceRef.current) u.voice = voiceRef.current
        u.onstart = () => setSpeaking(true)
        u.onend = () => setSpeaking(false)
        u.onerror = () => setSpeaking(false)
        window.speechSynthesis.speak(u)
      } catch (e) {
        console.log("[v0] Falha no sintetizador de voz:", (e as Error).message)
      }
    },
    [],
  )

  const stop = useCallback(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel()
      setSpeaking(false)
    }
  }, [])

  return { supported, speaking, speak, stop }
}
