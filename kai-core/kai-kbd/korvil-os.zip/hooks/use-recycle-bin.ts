"use client"

import { useCallback, useEffect, useState } from "react"
import {
  getRecycleBin,
  restoreFromBin,
  purgeFromBin,
  onDbChange,
  type RecycleEntry,
} from "@/lib/db"

export function useRecycleBin() {
  const [entries, setEntries] = useState<RecycleEntry[]>([])

  const refresh = useCallback(() => setEntries(getRecycleBin()), [])

  useEffect(() => {
    refresh()
    return onDbChange(refresh)
  }, [refresh])

  const restore = useCallback(
    (id: string) => {
      const ok = restoreFromBin(id)
      refresh()
      return ok
    },
    [refresh],
  )

  const purge = useCallback(
    (id: string) => {
      const ok = purgeFromBin(id)
      refresh()
      return ok
    },
    [refresh],
  )

  return { entries, refresh, restore, purge }
}
