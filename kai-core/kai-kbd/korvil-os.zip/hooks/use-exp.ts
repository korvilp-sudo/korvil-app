"use client"

// ============================================================================
// KORVIL OS — SISTEMA DE EXPERIENCIA (EXP / Level Up)
// Cada acao concede EXP. Curva progressiva. Persistido em LocalStorage.
// ============================================================================

import { useCallback, useEffect, useState } from "react"
import { LS_EXP_KEY } from "@/lib/constants"

export interface ExpState {
  xp: number
  level: number
  totalActions: number
}

const DEFAULT: ExpState = { xp: 0, level: 1, totalActions: 0 }

/** EXP necessaria para alcancar o proximo nivel. */
export function xpForLevel(level: number): number {
  return Math.floor(100 * Math.pow(level, 1.35))
}

function read(): ExpState {
  if (typeof window === "undefined") return DEFAULT
  try {
    const raw = window.localStorage.getItem(LS_EXP_KEY)
    return raw ? { ...DEFAULT, ...JSON.parse(raw) } : DEFAULT
  } catch {
    return DEFAULT
  }
}

const EVENT = "korvil-exp-change"

export function useExp() {
  const [state, setState] = useState<ExpState>(DEFAULT)
  const [justLeveled, setJustLeveled] = useState(false)

  useEffect(() => {
    setState(read())
    function sync() {
      setState(read())
    }
    window.addEventListener(EVENT, sync)
    window.addEventListener("storage", sync)
    return () => {
      window.removeEventListener(EVENT, sync)
      window.removeEventListener("storage", sync)
    }
  }, [])

  const gain = useCallback((amount: number) => {
    setState((prev) => {
      let { xp, level, totalActions } = prev
      xp += amount
      totalActions += 1
      let leveled = false
      while (xp >= xpForLevel(level)) {
        xp -= xpForLevel(level)
        level += 1
        leveled = true
      }
      const next = { xp, level, totalActions }
      if (typeof window !== "undefined") {
        window.localStorage.setItem(LS_EXP_KEY, JSON.stringify(next))
        window.dispatchEvent(new CustomEvent(EVENT))
      }
      if (leveled) {
        setJustLeveled(true)
        setTimeout(() => setJustLeveled(false), 3000)
      }
      return next
    })
  }, [])

  const reset = useCallback(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(LS_EXP_KEY, JSON.stringify(DEFAULT))
      window.dispatchEvent(new CustomEvent(EVENT))
    }
    setState(DEFAULT)
  }, [])

  const needed = xpForLevel(state.level)
  const percent = Math.min(100, Math.round((state.xp / needed) * 100))

  return { ...state, needed, percent, gain, reset, justLeveled }
}
