"use client"

import { useCallback, useEffect, useState } from "react"
import {
  getQueue,
  onQueueChange,
  enqueueCommit,
  processQueue,
  removeJob,
  clearQueue,
  getPat,
  setPat as persistPat,
  validatePat,
  type CommitJob,
} from "@/lib/github"

export function useGithubSync() {
  const [queue, setQueue] = useState<CommitJob[]>([])
  const [pat, setPatState] = useState<string | null>(null)
  const [processing, setProcessing] = useState(false)

  const refresh = useCallback(() => setQueue(getQueue()), [])

  useEffect(() => {
    refresh()
    setPatState(getPat())
    return onQueueChange(refresh)
  }, [refresh])

  const enqueue = useCallback(
    (path: string, content: string, message: string) => {
      const job = enqueueCommit(path, content, message)
      refresh()
      return job
    },
    [refresh],
  )

  const process = useCallback(async () => {
    setProcessing(true)
    const result = await processQueue()
    refresh()
    setProcessing(false)
    return result
  }, [refresh])

  const savePat = useCallback((value: string) => {
    persistPat(value)
    setPatState(value || null)
  }, [])

  const remove = useCallback(
    (id: string) => {
      removeJob(id)
      refresh()
    },
    [refresh],
  )

  const clear = useCallback(() => {
    clearQueue()
    refresh()
  }, [refresh])

  const pending = queue.filter((j) => j.status === "pending" || j.status === "failed").length
  const local = queue.filter((j) => j.status === "local").length

  return {
    queue,
    pat,
    hasPat: !!pat,
    processing,
    pending,
    local,
    enqueue,
    process,
    savePat,
    validatePat,
    remove,
    clear,
  }
}
