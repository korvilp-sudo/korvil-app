"use client"

// ============================================================================
// KORVIL OS — HOOK DE FORMULARIOS UNIVERSAIS
// Gerencia estado de um formulario derivado do esquema de setor/colecao,
// valida coerencia e persiste via engine de DB + fila de commit.
// ============================================================================

import { useCallback, useMemo, useState } from "react"
import { getCollection } from "@/lib/constants"
import { defaultsFor, validateRecord, type CoherenceIssue } from "@/lib/coherence-rules"
import { createRecord, updateRecord, type DbRecord } from "@/lib/db"

export function useForms(sector: string, collection: string) {
  const schema = useMemo(() => getCollection(sector, collection), [sector, collection])
  const [values, setValues] = useState<Record<string, unknown>>(() => defaultsFor(sector, collection))
  const [issues, setIssues] = useState<CoherenceIssue[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)

  const setField = useCallback((key: string, value: unknown) => {
    setValues((prev) => ({ ...prev, [key]: value }))
  }, [])

  const reset = useCallback(() => {
    setValues(defaultsFor(sector, collection))
    setIssues([])
    setEditingId(null)
  }, [sector, collection])

  const loadRecord = useCallback((rec: DbRecord) => {
    const { id, createdAt, updatedAt, ...rest } = rec
    void createdAt
    void updatedAt
    setValues(rest)
    setEditingId(id)
    setIssues([])
  }, [])

  /** Aplica um patch parcial (usado pela voz para autopreenchimento). */
  const applyPatch = useCallback((patch: Record<string, unknown>) => {
    setValues((prev) => ({ ...prev, ...patch }))
  }, [])

  const submit = useCallback((): { ok: boolean; record?: DbRecord; issues: CoherenceIssue[] } => {
    const result = validateRecord(sector, collection, values)
    setIssues(result.issues)
    if (!result.ok) return { ok: false, issues: result.issues }

    let record: DbRecord | null
    if (editingId) {
      record = updateRecord(sector, collection, editingId, values)
    } else {
      record = createRecord(sector, collection, values)
    }
    if (record) {
      reset()
      return { ok: true, record, issues: [] }
    }
    return { ok: false, issues: [{ field: "_", message: "Falha ao gravar registro." }] }
  }, [sector, collection, values, editingId, reset])

  return {
    schema,
    values,
    issues,
    editingId,
    isEditing: !!editingId,
    setField,
    applyPatch,
    loadRecord,
    reset,
    submit,
  }
}
