import { Analytics } from "@vercel/analytics/next"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import "./globals.css"
import { AppShell } from "@/components/app-shell"

const geistSans = Geist({
  subsets: ["latin"],
  variable: "--font-geist-sans",
})

const geistMono = Geist_Mono({
  subsets: ["latin"],
  variable: "--font-geist-mono",
})

export const metadata: Metadata = {
  title: "KORVIL OS — K-AI: Modo Forja",
  description:
    "K-AI (KORVIL OS): sistema operacional web autonomo, blindado e 100% funcional no navegador. Banco de dados modular, assistente de voz, lixeira de seguranca e Repo Forge.",
  generator: "v0.app",
  applicationName: "kai-kbd",
  keywords: ["KORVIL", "K-AI", "KORVIL OS", "K-B.D", "Modo Forja"],
  authors: [{ name: "KORVIL" }],
  icons: {
    icon: "/icon.svg",
  },
}

export const viewport: Viewport = {
  colorScheme: "dark",
  themeColor: "#04141a",
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className={`dark ${geistSans.variable} ${geistMono.variable}`}>
      <body className="antialiased bg-background text-foreground min-h-screen">
        <AppShell>{children}</AppShell>
        {process.env.NODE_ENV === "production" && <Analytics />}
      </body>
    </html>
  )
}
